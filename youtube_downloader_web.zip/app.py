from flask import Flask, render_template, request, send_from_directory
from yt_dlp import YoutubeDL
import os
import tempfile
import browser_cookie3

app = Flask(__name__)
DOWNLOAD_FOLDER = 'downloads'
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

def get_cookies_file(uploaded_file=None):
    if uploaded_file:
        temp_path = tempfile.NamedTemporaryFile(delete=False, suffix=".txt").name
        uploaded_file.save(temp_path)
        return temp_path
    try:
        cj = browser_cookie3.chrome(domain_name='youtube.com')
        cookie_file = tempfile.NamedTemporaryFile(delete=False, suffix=".txt")
        with open(cookie_file.name, 'w') as f:
            for cookie in cj:
                line = f"{cookie.domain}	{cookie.path}	{str(cookie.secure).upper()}	{cookie.expires}	{cookie.name}	{cookie.value}\n"
                f.write(line)
        return cookie_file.name
    except Exception:
        return None

def fetch_formats(url, cookie_file=None):
    ydl_opts = {}
    if cookie_file:
        ydl_opts['cookiefile'] = cookie_file
    with YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=False)
        formats = info.get('formats', [])
        res_list = []
        for f in formats:
            if f.get('vcodec') != 'none':
                format_id = f.get('format_id')
                ext = f.get('ext') or ''
                height = f.get('height') or 'unknown'
                label = f"{format_id} - {height}p ({ext})"
                if f.get('acodec') == 'none':
                    label += " [video-only]"
                else:
                    label += " [video+audio]"
                if label not in res_list:
                    res_list.append(label)
        def resolution_key(label):
            import re
            match = re.search(r'(\d+)p', label)
            return int(match.group(1)) if match else 0
        res_list.sort(key=resolution_key, reverse=True)
        return res_list

@app.route('/', methods=['GET', 'POST'])
def index():
    message = ''
    formats = []
    last_url = ''
    if request.method == 'POST':
        action = request.form.get('action')
        url = request.form.get('video_url') or request.form.get('playlist_url')
        last_url = url
        uploaded_cookie = request.files.get('cookie_file')
        cookie_file_to_use = get_cookies_file(uploaded_cookie)

        if not url:
            message = "Please enter a URL"
            return render_template('index.html', message=message, formats=formats, last_url=last_url)

        if action == 'fetch_formats':
            try:
                formats = fetch_formats(url, cookie_file_to_use)
            except Exception as e:
                message = str(e)
            return render_template('index.html', message=message, formats=formats, last_url=last_url)

        elif action == 'download_video':
            format_code = request.form.get('format_code')
            if not format_code:
                message = "Please select a format"
                return render_template('index.html', message=message, formats=formats, last_url=last_url)
            try:
                format_id = format_code.split(' - ')[0]
                ydl_opts = {
                    'outtmpl': os.path.join(DOWNLOAD_FOLDER, '%(title)s.%(ext)s'),
                    'format': format_id + '+bestaudio/best' if '[video-only]' in format_code else format_id
                }
                if cookie_file_to_use:
                    ydl_opts['cookiefile'] = cookie_file_to_use
                with YoutubeDL(ydl_opts) as ydl:
                    info = ydl.extract_info(url, download=True)
                    filename = ydl.prepare_filename(info)
                return send_from_directory(DOWNLOAD_FOLDER, os.path.basename(filename), as_attachment=True)
            except Exception as e:
                message = str(e)
                return render_template('index.html', message=message, formats=formats, last_url=last_url)

        elif action == 'download_playlist':
            try:
                ydl_opts = {
                    'outtmpl': os.path.join(DOWNLOAD_FOLDER, '%(playlist_index)s - %(title)s.%(ext)s'),
                    'ignoreerrors': True
                }
                if cookie_file_to_use:
                    ydl_opts['cookiefile'] = cookie_file_to_use
                with YoutubeDL(ydl_opts) as ydl:
                    ydl.download([url])
                message = "Playlist download completed!"
            except Exception as e:
                message = str(e)
            return render_template('index.html', message=message, formats=formats, last_url=last_url)

    return render_template('index.html', message=message, formats=formats, last_url=last_url)

if __name__ == '__main__':
    app.run(debug=True)
